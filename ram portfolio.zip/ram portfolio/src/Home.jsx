import React from 'react';

function Home() {
  return (
    <div>
      <h2>Home</h2>
      <p>Welcome to my portfolio! Here you can find my projects and skills.</p>
    </div>
  );
}

export default Home;
