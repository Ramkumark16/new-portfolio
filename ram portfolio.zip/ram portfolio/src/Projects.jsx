import React from 'react';

function Projects() {
  return (
    <div>
      <h2>Projects</h2>
      <div className="project">
        <h3>Project Title 1</h3>
        <p>Description of project 1.</p>
        <a href="https://link-to-project-1.com" target="_blank" rel="noopener noreferrer">View Project</a>
      </div>
      <div className="project">
        <h3>Project Title 2</h3>
        <p>Description of project 2.</p>
        <a href="https://link-to-project-2.com" target="_blank" rel="noopener noreferrer">View Project</a>
      </div>
      {/* Add more projects as needed */}
    </div>
  );
}

export default Projects;
