import React from 'react';

function Contact() {
  return (
    <div>
      <h2>Contact</h2>
      <p>If you'd like to get in touch, please reach out!</p>
      <p>Email: your-email@example.com</p>
    </div>
  );
}

export default Contact;
